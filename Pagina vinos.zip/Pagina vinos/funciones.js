const botonMenu = document.getElementById("botonMenu");
const navegacion = document.getElementById("navegacion");
 
if (botonMenu && navegacion) {
    botonMenu.addEventListener("click", function () {
        navegacion.classList.toggle("activo");
 
        const abierto = navegacion.classList.contains("activo");
 
        botonMenu.setAttribute("aria-expanded", abierto);
        botonMenu.textContent = abierto ? "✕" : "☰";
        botonMenu.setAttribute("aria-label", abierto ? "Cerrar menú" : "Abrir menú");
    });
 
    const enlaces = document.querySelectorAll(".navegacion a");
 
    enlaces.forEach(function (enlace) {
        enlace.addEventListener("click", function () {
            navegacion.classList.remove("activo");
            botonMenu.setAttribute("aria-expanded", "false");
            botonMenu.textContent = "☰";
            botonMenu.setAttribute("aria-label", "Abrir menú");
        });
    });
 
    document.addEventListener("click", function (evento) {
        if (!navegacion.contains(evento.target) && !botonMenu.contains(evento.target)) {
            navegacion.classList.remove("activo");
            botonMenu.setAttribute("aria-expanded", "false");
            botonMenu.textContent = "☰";
            botonMenu.setAttribute("aria-label", "Abrir menú");
        }
    });
}
 
const anio = document.getElementById("anio");
if (anio) {
    anio.textContent = new Date().getFullYear();
}
 
/* ==================== CARRITO ==================== */
 
const CLAVE_CARRITO = "carritoVinos";
 
function leerCarrito() {
    try {
        return JSON.parse(localStorage.getItem(CLAVE_CARRITO)) || {};
    } catch (e) {
        return {};
    }
}
 
function guardarCarrito(carrito) {
    try {
        localStorage.setItem(CLAVE_CARRITO, JSON.stringify(carrito));
    } catch (e) {}
}
 
// Suma o resta cantidad y devuelve la cantidad nueva
function cambiarCantidad(vino, cambio) {
    const carrito = leerCarrito();
    const actual = carrito[vino.nombre] ? carrito[vino.nombre].cantidad : 0;
    const nueva = Math.max(0, actual + cambio);
 
    if (nueva === 0) {
        delete carrito[vino.nombre];
    } else {
        carrito[vino.nombre] = {
            nombre: vino.nombre,
            tipo: vino.tipo,
            descripcion: vino.descripcion,
            imagen: vino.imagen,
            cantidad: nueva
        };
    }
 
    guardarCarrito(carrito);
    return nueva;
}
 
/* ---------- Página de vinos ---------- */
 
document.querySelectorAll(".tarjeta-vino").forEach(function (tarjeta) {
    const vino = {
        nombre: tarjeta.querySelector("h3").textContent.trim(),
        tipo: tarjeta.querySelector(".informacion-vino > span").textContent.trim(),
        descripcion: tarjeta.querySelector(".informacion-vino > p").textContent.trim(),
        imagen: tarjeta.querySelector(".imagen-vino img").getAttribute("src")
    };
 
    const contador = tarjeta.querySelector(".selector-cantidad span");
    const botonMenos = tarjeta.querySelector('[aria-label="Disminuir cantidad"]');
    const botonMas = tarjeta.querySelector('[aria-label="Aumentar cantidad"]');
    const botonCarrito = tarjeta.querySelector(".boton-carrito");
 
    // Al volver a la página, muestra lo que ya estaba elegido
    const carritoActual = leerCarrito();
    contador.textContent = carritoActual[vino.nombre] ? carritoActual[vino.nombre].cantidad : 0;
 
    botonMas.addEventListener("click", function () {
        contador.textContent = cambiarCantidad(vino, 1);
    });
 
    botonMenos.addEventListener("click", function () {
        contador.textContent = cambiarCantidad(vino, -1);
    });
 
    botonCarrito.addEventListener("click", function () {
        window.location.href = "carrito.html";
    });
});
 
/* ---------- Página del carrito ---------- */
 
function crear(etiqueta, clase, texto) {
    const el = document.createElement(etiqueta);
    if (clase) el.className = clase;
    if (texto !== undefined) el.textContent = texto;
    return el;
}
 
function dibujarCarrito() {
    const lista = document.querySelector(".lista-carrito");
    const vacio = document.querySelector(".carrito-vacio");
    const items = Object.values(leerCarrito());
 
    lista.innerHTML = "";
    vacio.style.display = items.length ? "none" : "block";
 
    items.forEach(function (vino) {
        const articulo = crear("article", "producto-carrito");
 
        const cajaImagen = crear("div", "imagen-carrito");
        const img = document.createElement("img");
        img.src = vino.imagen;
        img.alt = vino.nombre;
        cajaImagen.appendChild(img);
 
        const datos = crear("div", "datos-carrito");
        datos.appendChild(crear("span", "", vino.tipo));
        datos.appendChild(crear("h3", "", vino.nombre));
        datos.appendChild(crear("p", "", vino.descripcion));
 
        const cantidad = crear("div", "cantidad-carrito");
        cantidad.appendChild(crear("span", "", "Cantidad"));
 
        const selector = crear("div", "selector-cantidad");
        const menos = crear("button", "", "−");
        const numero = crear("span", "", vino.cantidad);
        const mas = crear("button", "", "+");
        menos.type = "button";
        mas.type = "button";
        menos.setAttribute("aria-label", "Disminuir cantidad");
        mas.setAttribute("aria-label", "Aumentar cantidad");
 
        menos.addEventListener("click", function () {
            cambiarCantidad(vino, -1);
            dibujarCarrito();
        });
        mas.addEventListener("click", function () {
            cambiarCantidad(vino, 1);
            dibujarCarrito();
        });
 
        selector.append(menos, numero, mas);
        cantidad.appendChild(selector);
        datos.appendChild(cantidad);
 
        articulo.append(cajaImagen, datos);
        lista.appendChild(articulo);
    });
}
 
if (document.querySelector(".lista-carrito")) {
    dibujarCarrito();
}